# Task 1 
#!/bin/bash

# create the array 
files=("document.txt" "photo.jpg" "data.csv" "presentation.ppt" "script.sh" "notes.docx" "archive.zip")

# loop through each file and print the appropriate message based on extension
for file in "${files[@]}"; do
    if [[ $file == *.txt ]]; then
        echo "Moving $file to Text_Files folder"
    elif [[ $file == *.jpg ]]; then
        echo "Moving $file to Images folder"
    elif [[ $file == *.csv ]]; then
        echo "Moving $file to CSV_Files folder"
    elif [[ $file == *.sh ]]; then
        echo "Moving $file to Scripts folder"
    elif [[ $file == *.docx ]]; then
        echo "Moving $file to Documents folder"
    elif [[ $file == *.zip ]]; then
        echo "Moving $file to Archives folder"
    else
        echo "File type of $file is not recognized, no folder specified."
    fi
done