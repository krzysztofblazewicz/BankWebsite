# Task 2 
#!/bin/bash

disk_usage=85 # example disk usage  
threshold=80 # example threshold 

# compare disk usage to the threshold and print warning if it exceeds otherwise print that the disk usage is within acceptable range
if (( disk_usage > threshold )); then
    echo "Warning: Disk usage is at ${disk_usage}%, which exceeds the threshold!"
else
    echo "Disk usage is at ${disk_usage}%, which is within the acceptable range."
fi