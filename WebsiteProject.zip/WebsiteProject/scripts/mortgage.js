$(document).ready(function(){
    const ANNUAL_RATE = 0.045; // constant annual rate 
    const MONTHLY_RATE = ANNUAL_RATE / 12; // convert annual rate to monthly rate 
    $("#mortgageForm").submit(function (event){ // event listener for mortgage form submission 
        event.preventDefault(); // prevent empty form submission 
        const loanAmount = parseFloat($("#loanAmount").val()); // loan amount 
        const loanTerm = parseInt($("#loanTerm").val()) * 12; // total payments
        const monthlyIncome = parseFloat($("#monthlyIncome").val()); // monthly income 
        if([loanAmount, loanTerm, monthlyIncome].some(isNaN)){ // check for valid inputs 
            alert("Please enter valid numbers for all fields!"); // error message 
            return; // stop execution 
        }
        const monthlyPayment = calculateMonthlyPayment(loanAmount, MONTHLY_RATE, loanTerm);
        const totalRepaid = monthlyPayment * loanTerm;
        const incomeThreshold = monthlyIncome * 0.30;
        $("#monthlyPayment").text(monthlyPayment.toFixed(2));
        $("#totalInterest").text((totalRepaid - loanAmount).toFixed(2));
        $("#totalAmountRepaid").text(totalRepaid.toFixed(2));
        $("#eligibility").text(monthlyPayment > incomeThreshold ? "(Denied) Exceeds 30% of income." : "(Approved) Within 30% of income.");
        $("#result").fadeIn(500); // result animation 
    }); // function to calculate monthly payments using the formula 
    function calculateMonthlyPayment(P, r, n){
        return P * r * (1 + r) ** n / ((1 + r) ** n - 1);
    }
});